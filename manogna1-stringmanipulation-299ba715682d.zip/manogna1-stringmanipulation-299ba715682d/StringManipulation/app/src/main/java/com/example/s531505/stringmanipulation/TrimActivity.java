package com.example.s531505.stringmanipulation;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class TrimActivity extends AppCompatActivity {

    String msg;
    String result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trim);
        Intent init=getIntent();
        msg=init.getStringExtra("src");
        TextView tv=findViewById(R.id.srcTV);
        tv.setText(msg);
        Toast.makeText(TrimActivity.this,
                "You are in Trim Char activity", Toast.LENGTH_LONG).show();
    }

    public void trimChar(View v) {
        try{
            TextView ftv = findViewById(R.id.srcTV);
            String text = ftv.getText().toString();
            EditText etv = findViewById(R.id.charTV);
            int i = Integer.parseInt(etv.getText().toString());
          String result=text.substring(i,text.length()-i);
            TextView ttv = findViewById(R.id.trimTV);
            ttv.setText(result);}
        catch(Exception ex){
            TextView ttv = findViewById(R.id.trimTV);
            ttv.setText("Error!!!! please enter a number to perform shift operation");
        }
    }
    public void cancel(View v){
        Intent init=getIntent();
        init.putExtra("msg",msg);
        setResult(0,init);
        finish();
    }
}
