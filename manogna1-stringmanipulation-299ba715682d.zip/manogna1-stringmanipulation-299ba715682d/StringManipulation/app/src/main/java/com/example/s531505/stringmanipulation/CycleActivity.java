package com.example.s531505.stringmanipulation;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CycleActivity extends Activity {

    String msg;
    String result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cycle);
        Intent init=getIntent();
        msg=init.getStringExtra("src");
        TextView tv=findViewById(R.id.firstCTV);
        tv.setText(msg);
        Toast.makeText(CycleActivity.this,
                "You are in Cycle activity", Toast.LENGTH_LONG).show();
    }
    public void applyC(View v){
        Intent init=getIntent();
        init.putExtra("msg",result);
        setResult(1,init);
        finish();
    }
    String sr;
    public void showC(View v){
        try{
        TextView rtv=findViewById(R.id.firstCTV);
        String src=rtv.getText().toString();
        sr=src;
       EditText cet=findViewById(R.id.cycleET);
       int i=Integer.parseInt(cet.getText().toString());
       for(int n=0;n<i;n++){
       String s=src.substring(0,1);
       src=src.substring(1);
       src=src.concat(s);}
        TextView tctv=findViewById(R.id.transCTV);
        tctv.setText(src);
        result=tctv.getText().toString();}
        catch(Exception ex){
            TextView tv=findViewById(R.id.tvC);
            tv.setText("Error!!!! please enter only number. No strings and special characters allowed!");
        }
        Toast.makeText(CycleActivity.this,
                "Text cycled successfully", Toast.LENGTH_LONG).show();
    }
    public void cancelC(View v){
        Intent init=getIntent();
        init.putExtra("msg",msg);
      setResult(0,init);
      finish();
    }
}
