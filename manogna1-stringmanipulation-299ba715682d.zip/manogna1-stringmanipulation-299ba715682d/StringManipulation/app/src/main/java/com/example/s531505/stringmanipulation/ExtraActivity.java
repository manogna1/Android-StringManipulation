package com.example.s531505.stringmanipulation;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ExtraActivity extends AppCompatActivity {
String msg;
String result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_extra);
        Intent init=getIntent();
        msg=init.getStringExtra("src");
        TextView tv=findViewById(R.id.srcETV);
        tv.setText(msg);
        Toast.makeText(ExtraActivity.this,
                "You are in Shift Char activity", Toast.LENGTH_LONG).show();
    }

    public void shiftChar(View v) {
        try{
        TextView ftv = findViewById(R.id.srcETV);
        String text = ftv.getText().toString();
        EditText etv = findViewById(R.id.shuffleET);
        int i = Integer.parseInt(etv.getText().toString());
        String result="";
        for (char c : text.toCharArray()) {
            if(c!=' '){
           result+= Character.toString((char) (((c - 'a' + i) % 26) + 'a'));}
           else{
                result+=" ";
            }
        }
        TextView ttv = findViewById(R.id.transETV);
        ttv.setText(result);}
        catch(Exception ex){
            TextView ttv = findViewById(R.id.transETV);
            ttv.setText("Error!!!! please enter a number to perform shift operation");
        }
    }
    public void cancel(View v){
        Intent init=getIntent();
        init.putExtra("msg",msg);
        setResult(0,init);
        finish();
    }
}
