package com.example.s531505.stringmanipulation;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class StartActivity extends AppCompatActivity {

private String[] items={"Replace activity","Cycle activity","Shift Char Activity","Trim Activity"};
//private String[] desc={"Replaces the string as you given","Cycles the text as many times as you wish","Shift each char of the string in alphabetical order"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.dummy_layout,R.id.tv1,items);


        ListView lv = findViewById(R.id.listTV);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            public void onItemClick( AdapterView<?> parent, View view,int position, long id)
            {
                if(id == 0){
                    Intent init=new Intent(StartActivity.this,ReplaceActivity.class);
                    EditText et=findViewById(R.id.source);
                    String s=et.getText().toString();
                    init.putExtra("src",s);
                    if (s.length() != 0) {
                    startActivityForResult(init,1);}
                    else{
                        et.setHint("Enter string before performing activity");
                    }
                }
                else if(id == 1){
                    Intent init=new Intent(StartActivity.this,CycleActivity.class);
                    EditText et=findViewById(R.id.source);
                    String s=et.getText().toString();
                    init.putExtra("src",s);
                    if (s.length() != 0) {
                        startActivityForResult(init,1);}
                    else{
                        et.setHint("Enter string before performing activity");
                    }
                }
                else if(id==2){
                    Intent init=new Intent(StartActivity.this,ExtraActivity.class);
                    EditText et=findViewById(R.id.source);
                    String s=et.getText().toString();
                    init.putExtra("src",s);
                    if (s.length() != 0) {
                        startActivityForResult(init,1);}
                    else{
                        et.setHint("Enter string before performing activity");
                    }
                }
                else{
                    Intent init=new Intent(StartActivity.this,TrimActivity.class);
                    EditText et=findViewById(R.id.source);
                    String s=et.getText().toString();
                    init.putExtra("src",s);
                    if (s.length() != 0) {
                        startActivityForResult(init,1);}
                    else{
                        et.setHint("Enter string before performing activity");
                    }
                }
            }
        }
        );
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == 1) {
            String result = data.getStringExtra("msg");
            EditText et = findViewById(R.id.source);
            et.setText(result);
            Toast.makeText(StartActivity.this,
                    "Source text changed", Toast.LENGTH_LONG).show();
        } else {
            try {
                String result = data.getStringExtra("msg");
                EditText et = findViewById(R.id.source);
                et.setText(result);
                Toast.makeText(StartActivity.this,
                        "You are in start activity", Toast.LENGTH_LONG).show();
            } catch (Exception ex) {

            }
        }
    }}
