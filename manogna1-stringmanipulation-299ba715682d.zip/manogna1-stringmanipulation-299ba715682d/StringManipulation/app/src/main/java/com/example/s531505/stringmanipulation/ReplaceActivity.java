package com.example.s531505.stringmanipulation;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ReplaceActivity extends AppCompatActivity {

String msg;
    String sr,src;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_replace);
        Intent init=getIntent();
        msg=init.getStringExtra("src");
        TextView tv=findViewById(R.id.firstTV);
        tv.setText(msg);
        Toast.makeText(ReplaceActivity.this,
                "You are in replace activity", Toast.LENGTH_LONG).show();
    }
    public void applyR(View v){
        Intent init=getIntent();
        init.putExtra("msg",src);
        setResult(1,init);
        finish();
    }

    public void showR(View v){
        TextView rtv=findViewById(R.id.firstTV);
        src=rtv.getText().toString();
        sr=src;
        EditText etto=findViewById(R.id.replaceTV);
        EditText etwith=findViewById(R.id.transTV);
        String s1=etto.getText().toString();
        String s2=etwith.getText().toString();
        src=src.replaceAll(s1,s2);
        TextView ttv=findViewById(R.id.secondTV);
        ttv.setText(src);
        Toast.makeText(ReplaceActivity.this,
                "Text successfully replaced", Toast.LENGTH_LONG).show();

    }
    public void cancelR(View v){
        Intent init=getIntent();
        init.putExtra("msg",msg);
        setResult(0,init);
        finish();
    }
}
